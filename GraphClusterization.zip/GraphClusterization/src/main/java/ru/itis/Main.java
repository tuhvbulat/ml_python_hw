package ru.itis;

import guru.nidi.graphviz.engine.Format;
import guru.nidi.graphviz.engine.Graphviz;
import guru.nidi.graphviz.model.MutableGraph;
import guru.nidi.graphviz.parse.Parser;
import org.jgrapht.graph.DefaultUndirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws IOException {
        getGraph();
    }

    public static DefaultUndirectedWeightedGraph<Point, DefaultWeightedEdge> getGraph() throws IOException {
        DefaultUndirectedWeightedGraph<Point, DefaultWeightedEdge> g = new DefaultUndirectedWeightedGraph<>(DefaultWeightedEdge.class);
        GraphCluster graphCluster = new GraphCluster(g);
        int n = 20;
        int k = 3;
        var points = generatePoints(n);
        System.out.println(points);
        for (int i = 0; i < n; i++) {
            graphCluster.addVertex(points.get(i));
        }
        graphCluster.buildGraph();
        var edgesBeforeDelete = graphCluster.getGraph().edgeSet();
        System.out.println(edgesBeforeDelete);
        outputGraphWithGraphviz(graphCluster.toGraphvizFormat(), "fullTree");
        graphCluster.findClusters(k);
        var edgesAfterDelete = graphCluster.getGraph().edgeSet();;
        System.out.println(edgesAfterDelete);
        System.out.println(graphCluster.getDeletedEdges());
        outputGraphWithGraphviz(graphCluster.toGraphvizFormat(), "clusters");
        return graphCluster.getGraph();
    }

    public static List<Point> generatePoints(int n) {
        var list = new ArrayList<Point>();
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            list.add(new Point(i, random.nextInt(100), random.nextInt(100)));
        }
        return list;
    }

    public static void outputGraphWithGraphviz(String graphEncoded, String filename) throws IOException {
        MutableGraph g = new Parser().read(graphEncoded);
        Graphviz.fromGraph(g).width(700).render(Format.PNG).toFile(new File(filename + ".png"));
    }

}
