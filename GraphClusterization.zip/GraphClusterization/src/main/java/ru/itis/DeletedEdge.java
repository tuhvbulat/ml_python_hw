package ru.itis;

import org.jgrapht.graph.DefaultWeightedEdge;

import java.util.Objects;

public class DeletedEdge {

    private DefaultWeightedEdge edge;
    private double dist;

    public DeletedEdge(DefaultWeightedEdge edge, double dist) {
        this.edge = edge;
        this.dist = dist;
    }

    public DefaultWeightedEdge getEdge() {
        return edge;
    }

    public void setEdge(DefaultWeightedEdge edge) {
        this.edge = edge;
    }

    public double getDist() {
        return dist;
    }

    public void setDist(double dist) {
        this.dist = dist;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DeletedEdge that = (DeletedEdge) o;
        return Double.compare(that.dist, dist) == 0 && Objects.equals(edge, that.edge);
    }

    @Override
    public int hashCode() {
        return Objects.hash(edge, dist);
    }

    @Override
    public String toString() {
        return "DeletedEdge{" +
                "edge=" + edge +
                ", dist=" + dist +
                '}';
    }
}
